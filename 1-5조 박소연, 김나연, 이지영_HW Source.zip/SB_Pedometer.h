/*=============================================================================*/
/***********************Function Prototype**************************************/
/*=============================================================================*/
#include "hal_types.h"
	

/*==============================================================================*/
/*****************************Defines********************************************/
/*==============================================================================*/

//Threshold limits (OK)

#define LAZY_WALKING_LOWER_LIMIT_Robust         150//50>>V_DivideFactor_U8R //< Composite Lower Threshold for Lazy Walk step
#define LAZY_WALKING_LOWER_LIMIT_NoRobust       32>>V_DivideFactor_U8R //< Composite Lower Threshold for Lazy Walk step
#define LAZY_WALKING_UPPER_LIMIT                450//320>>V_DivideFactor_U8R //< Composite Upper Threshold for Lazy Walk step


#define WALKING_LOWER_LIMIT                     450//300>>V_DivideFactor_U8R //< Composite Lower Threshold for Walk step
#define WALKING_UPPER_LIMIT                     1500//550>>V_DivideFactor_U8R //< Composite Upper Threshold for Walk step


#define SMALL_WALKING_LOWER_LIMIT               250//300>>V_DivideFactor_U8R //< Composite Lower Threshold for Walk step
#define SMALL_WALKING_UPPER_LIMIT               1500//550>>V_DivideFactor_U8R //< Composite Upper Threshold for Walk step


#define JOG_LOWER_LIMIT                         1500//500>>V_DivideFactor_U8R //< Composite Lower Threshold for Jog step 
#define JOG_UPPER_LIMIT                         3000//1200>>V_DivideFactor_U8R //< Composite Upper Threshold for Jog step

#define BARK_LOWER_LIMIT						150

#define C_SensorNoiseLevel_U8X                  16>>V_DivideFactor_U8R //< Variation Of Acceleration Value When kept idle 

/*******************************Trend limits*************************************/

#define LAZY_WALKING_CYCLE_LOWER_LIMIT          15	//< Trend cycle upper limit for lazy walking
#define LAZY_WALKING_CYCLE_UPPER_LIMIT          40	//< Trend cycle upper limit for lazy walking


#define WALKING_CYCLE_LOWER_LIMIT               10	//<Trend cycle lower limit for walking
#define WALKING_CYCLE_UPPER_LIMIT               25	//< Trend cycle upper limit for walking


#define SMALL_WALKING_CYCLE_LOWER_LIMIT         20	//<Trend cycle lower limit for walking
#define SMALL_WALKING_CYCLE_UPPER_LIMIT         40	//< Trend cycle upper limit for walking

#define JOG_CYCLE_LOWER_LIMIT                   2	//< Trend cycle lower limit for jogging
#define JOG_CYCLE_UPPER_LIMIT                   25	//< Trend cycle upper limit for jogging

#define BARK_CYCLE_LOWER_LIMIT					3

#define MAX_COUNT_DIFFERENCE                    3	//< Difference between 2 adjacent steps

/***************************Count Step to Step Limits***************************/

#define C_LazyWalkStepToStepLowerLimit_U8X      15 //< Count step to step lower limit for lazy walk
#define C_LazyWalkStepToStepUpperLimit_U8X      40 //< Count step to step upper limit for lazy walk
#define C_WalkStepToStepLowerLimit_U8X          10 //< Count step to step lower limit for walk
#define C_WalkStepToStepUpperLimit_U8X          20 //< Count step to step upper limit for walk
#define C_SmallWalkStepToStepLowerLimit_U8X     15 //< Count step to step lower limit for walk
#define C_SmallWalkStepToStepUpperLimit_U8X     40 //< Count step to step upper limit for walk
#define C_JogStepToStepLowerLimit_U8X            2 //< Count step to step lower limit for Jog
#define C_JogStepToStepUpperLimit_U8X           25 //< Count step to step upper limit for Jog
#define C_BarkLowerLimit_U8X					190 //< Count step to step lower limit for Bark

/****************************Mode definition*************************************/

#define M_Bark_U8X								(char)0x08

#define MODE_DETECTION                          0/**< First 4 steps yet to be made*/
#define MODE_COUNTING                           1/**< Walking mode (made 4 steps)*/
#define MODE_SLEEPING                           2/**< Sleeping mode*/

#define M_Walk_U8X                              (char)0x01    /**< Mask Bit for Walk*/
#define M_SlowWalk_U8X                          (char)0x02    /**< Mask Bit for Slow Walk*/
#define M_Jog_U8X                               (char)0x04    /**< Mask Bit for Jog*/

#define M_ModeDetection_U8X                   (char)0x01    /**< Mask Bit for Detection Mode*/
#define M_ModeCounting_U8X                    (char)0x02    /**< Mask Bit for Counting Mode*/
#define M_AlgoReset_U8X                       (char)0x04    /**< Mask Bit for Algo reset*/
#define M_Qualified_U8X                       (char)0x08    /**< Mask Bit for Qualified Step*/

#define M_UnQualified_U8X                     (char)0x10    /**< Mask Bit for UnQualified Step*/
#define M_PositiveTrend_U8X                   (char)0x20    /**< Mask Bit for Positive Trend Change*/
#define M_NegativeTrend_U8X                   (char)0x40    /**< Mask Bit for Negative Trend Change*/
#define M_DisableRobustness_U8X               (char)0x80    /**< Mask Bit for Disable robustness feature*/

#define AS_Rest_U8X                             (char)0x00    /**< Mask Bit for Lazy*/
#define AS_Walk_U8X                             (char)0x01    /**< Mask Bit for Walk*/
#define AS_Play_U8X                             (char)0x02    /**< Mask Bit for Play*/

//#define V_one_SecCount			(char)3000    /**< Mask Bit for Play*/
//#define V_one_SecCount				(char)455    /**< Mask Bit for Play*/ //30��
#define V_one_SecCount				(char)2727    /**< Mask Bit for Play*/ //30��


/****************************Macros dcifing the step Nature**********************/

/** \brief Macro Deciding Lazy walk step
*/
/** \brief Macro deciding Bark step
*/
#define IS_BARK(resultDiff_i16) \
		 ((resultDiff_i16 >= C_BarkLowerLimit_U8X) && \
		(s_sampleCountForCycle_i16 >= BARK_CYCLE_LOWER_LIMIT))


#define IS_LAZY_WALK_STEP(resultDiff_i16) \
        ((resultDiff_i16 >= V_LazyWalkLowerLimit_U8R &&  \
                resultDiff_i16 <= LAZY_WALKING_UPPER_LIMIT) && \
        (s_sampleCountForCycle_i16 >= LAZY_WALKING_CYCLE_LOWER_LIMIT && \
                s_sampleCountForCycle_i16 <= LAZY_WALKING_CYCLE_UPPER_LIMIT))

/** \brief Macro deciding Walk step
*/
#define IS_WALK_STEP(resultDiff_i16) \
        ((resultDiff_i16 >= WALKING_LOWER_LIMIT &&  \
                resultDiff_i16 <= WALKING_UPPER_LIMIT) && \
        (s_sampleCountForCycle_i16 >= WALKING_CYCLE_LOWER_LIMIT && \
                s_sampleCountForCycle_i16 <= WALKING_CYCLE_UPPER_LIMIT))

/** \brief Macro deciding Walk step
*/
#define IS_SMALL_WALK_STEP(resultDiff_i16) \
        ((resultDiff_i16 >= SMALL_WALKING_LOWER_LIMIT &&  \
                resultDiff_i16 <= SMALL_WALKING_UPPER_LIMIT) && \
        (s_sampleCountForCycle_i16 >= SMALL_WALKING_CYCLE_LOWER_LIMIT && \
                s_sampleCountForCycle_i16 <= SMALL_WALKING_CYCLE_UPPER_LIMIT))

/** \brief Macro deciding Jog step
*/
#define IS_JOG_STEP(resultDiff_i16) \
        ((resultDiff_i16 >= JOG_LOWER_LIMIT &&  \
                resultDiff_i16 <= JOG_UPPER_LIMIT) && \
        (s_sampleCountForCycle_i16 >= JOG_CYCLE_LOWER_LIMIT && \
                s_sampleCountForCycle_i16 <= JOG_CYCLE_UPPER_LIMIT))

/*================================================================================*/
/* EasyCASE - */
#define C_FilterTaps_U8X					(char)24 /**< Filter taps*/

//#define C_Q15ConversionFactor_U8X				(char)15 /**< Division Factor for Q 15*/
#define C_Q15ConversionFactor_U8X				(char)11 /**< Division Factor for Q 15*/

#define C_Clear_U8X						(char)0 /**<For clearing to  0*/
/* EasyCASE - */
#define C_CountZero_U8X						(char)0 /**<For Counter purpose 0*/
#define C_CountOne_U8X						(char)1 /**<For Counter purpose 1*/
/* EasyCASE - */
//#define C_DetectionModeTimeOut_U8X			(char)70 /**<Detection Mode time out upper limit (2.8 seconds)*/
//#define C_CountingModeTimeOut_U8X				(char)100 /**<Counting Mode time out upper limit (4 seconds)*/
#define C_DetectionModeTimeOut_U8X				(char)70 /**<Detection Mode time out upper limit (2.8 seconds)*/
#define C_CountingModeTimeOut_U8X				(char)100 /**<Counting Mode time out upper limit (4 seconds)*/


#define C_ErrorCountLimit_U8X					(char)5  /**<Limit for error count*/

//#define C_CorrectionCountLimit_U8X				(char)3  /**<Limit for Correction count*/
#define C_CorrectionCountLimit_U8X				(char)5  /**<Limit for Correction count*/


//#define C_InterStepCountLimit_U8X				(char)3  /**<Limit for Inter count*/
#define C_InterStepCountLimit_U8X				(char)5  /**<Limit for Inter count*/
#define C_InterStepCountLimitNoRobustness			(char)0  /**<Limit for Inter count*/	

/* Get the Activity of the pedometer */
void InitAlgo(uint8 v_GRange_u8r);

/* Get the step count */
short processAccelarationData(int8 *f_x_i16, int8 *f_y_i16, int8 *f_z_i16);
void Active_statusRead(uint16 *Acti_L, uint16 *Acti_W, uint16 *Acti_P);

unsigned char getActivity(void);
static void trendFinder(uint16, uint16*);
static short getAbsoluteShort(int8 f_val_i16);
extern void pedometerProcess( void );
void Total_MShift(uint8 Temp_A);

