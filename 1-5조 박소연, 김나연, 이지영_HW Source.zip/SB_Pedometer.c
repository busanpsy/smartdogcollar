/*============================================================================*/
/****************************Includes******************************************/
/*============================================================================*/
#include "SB_Pedometer.h"
#include "SB_BMA250.h"
#include "systemGlobal.h"

/*============================================================================*/
/** Global Variable Decleration                                              **/
/*============================================================================*/

//=========================================================
// Step Variable
//=========================================================

//3�� ���� ��
int8 new_x, new_y, new_z;

// Ȱ����
uint16 activity_total;	//point
uint16 temp_activity_total;

/* Initialise the composite value to 0 */
uint16 composite_i16;

//static uint8 Status_FLAG=C_Clear_U8X;
#define F_1SECT_U8X			(char)0x01    /**< Mask Bit for */
#define F_10MINT_U8X			(char)0x02    /**< Mask Bit for */
//#define F_AlgoReset_U8X		(char)0x04    /**< Mask Bit for */
//#define F_Qualified_U8X		(char)0x08    /**< Mask Bit for */
//#define F_ModeDetection_U8X		(char)0x10    /**< Mask Bit for */
//#define F_ModeCounting_U8X		(char)0x20    /**< Mask Bit for */
//#define F_AlgoReset_U8X		(char)0x40    /**< Mask Bit for */
//#define F_Qualified_U8X		(char)0x80    /**< Mask Bit for */

/**\brief Holds the pedometer activity*/
uint8 V_Activity_U8;

/**\brief Holds last reset value */
uint16 gs_stepCount_i16;

/**\brief Variable holds the division factor for the threshold*/
uint8 V_DivideFactor_U8R;

/**\brief Variable holds the Status Flags used*/
uint8 V_StatusFlags_U8R;

/* \brief Holds the 26 input values to the filter*/
static short gs_CompositeFilter[C_FilterTaps_U8X];

/* \brief Holds the lazy walk lower limit threshold*/
uint16 V_LazyWalkLowerLimit_U8R =C_Clear_U8X;

/* \brief Holds the Filter coefficients for 0.24 in Q15 format*/
/* EasyCASE - */
/* EasyCASE < */
static const short gc_CompositeFilterCoeff[C_FilterTaps_U8X] =
{
	58,
	134,
	173,
	45,
	-324,
	-802,
	-999,
	-422,
	1192,
	3614,
	6078,
	7637,
	7637,
	6078,
	3614,
	1192,
	-422,
	-999,
	-802,
	-324,
	45,
	173,
	134,
	58
};
//=========================================================
// Active Variable
//=========================================================

/* Activity ���� */
//static uint32 TempTotalActive = 0xFFFFF;

/* Active Status ����*/
static uint16 Acti_Lazy=0x00, Acti_Walk=0x00, Acti_Play=0x00;

uint16 T_Acti_add;
uint16 T_Acti_add_1;

/* Active Status B/T ����*/
uint8 acti_state_L=C_Clear_U8X,acti_state_M=C_Clear_U8X,acti_state_H=C_Clear_U8X;

/* Active Status ���� �� üũ*/
//static uint16 one_SecCount = V_one_SecCount;


/*============================================================================*/
/**   LOCAL Variable Decleration                                             **/
/*============================================================================*/

/*******************************************************************************
  Function Name   : short processAccelarationData()
  Input           : short f_x_i16
                    short f_y_i16
                    short f_z_i16
  Output          : Composite value
*******************************************************************************/
uint32 distance;
uint16 step_count, bark_count;
uint16 length;

short processAccelarationData(int8 *f_x_i16, int8 *f_y_i16, int8 *f_z_i16)
{
	/* Holds the steps counted while not in counting */
	static uint8     s_interStepCount_i8=0;
	/* 0 if there is no correction. correction value if there needs to be a correction */
	static uint8     s_correctionCount_i8=0;
	/* Holds the composite high for the step cycle */
	static uint16    s_resultHigh_i16=0x7FFF;
	/* Holds the sample counts between trend changes */
	static uint8    s_sampleCountForCycle_i16=0;
	/* Holds the time count between second last & last step */
	static uint8    s_countStepToStepPrev1_i16=0;
	/* Holds the time count between third last & second last step */
	static uint8     s_countStepToStepPrev2_i16=0;
	/* Holds the time count between last & this step */
	static uint8    gs_countStepToStep_i16=0;
	/*Holds error count between 2 steps*/
	static uint8 v_ErrorCount_u8=0;
	/*Holds the count between two consecutive counts*/
	static uint8 s_ModeTimer_i8=0;
	/*Holds prev Result Diff*/
	static uint16 v_PreResultDiff_s16r=0;
	/*Holds the previous activity type*/
	static uint8 v_PreviousActivity_u8=0;
	/* Initialise the composite value to 0 */
	//uint16  composite_i16;
	/* Initialise the filter result value to 0 */
	int32 FilterResult_l32;
	/*brief Used to hold index for filtering \n*/
	uint8 gs_FilterIndex;
	/*The previous status are stored*/
	static uint8 v_PreStatusFlags_u8r=0;
        
	/* Check whether the mode is sleeping mode */
	if (V_StatusFlags_U8R & (M_ModeDetection_U8X|M_ModeCounting_U8X))
	{
	}
	else{
		return 0;
	}
	
	if (V_StatusFlags_U8R & M_AlgoReset_U8X)
	{
		/* Set the reset the previous data as 0 */
		V_StatusFlags_U8R &= ~M_AlgoReset_U8X;
		/* Holds the steps counted while not in counting */
		s_interStepCount_i8=C_Clear_U8X;
		/* 0 if there is no correction. correction value if there needs to be a correction */
		s_correctionCount_i8=C_Clear_U8X;
		/* Holds the composite high for the step cycle */
		s_resultHigh_i16=0x7FFF;
		/* Holds the sample counts between trend changes */
		s_sampleCountForCycle_i16=C_Clear_U8X;
		/* Holds the time count between second last & last step */
		s_countStepToStepPrev1_i16=C_Clear_U8X;
		/* Holds the time count between third last & second last step */
		s_countStepToStepPrev2_i16=C_Clear_U8X;
		/* Holds the time count between last & this step */
		gs_countStepToStep_i16=C_Clear_U8X;
		/*Holds the previous activity type*/
		v_PreviousActivity_u8=C_Clear_U8X;
		/*Holds error count between 2 steps*/
		v_ErrorCount_u8=C_Clear_U8X;
		/*Holds the count between two consecutive counts*/
		s_ModeTimer_i8=C_Clear_U8X;
		/*Holds prev Result Diff*/
		v_PreResultDiff_s16r=C_Clear_U8X;
		/*The variable holding filter result are cleared*/
		FilterResult_l32=C_Clear_U8X;
		for (gs_FilterIndex=0;gs_FilterIndex<C_FilterTaps_U8X;gs_FilterIndex++)
		{
			gs_CompositeFilter[gs_FilterIndex] = C_Clear_U8X;
		}
	}
	/* EasyCASE ) */
	/* EasyCASE ( 213 Change in Robstness feature */
	/*Check whether robustness feature status changed*/
	if (((V_StatusFlags_U8R & M_DisableRobustness_U8X)!=(v_PreStatusFlags_u8r & M_DisableRobustness_U8X)))
	{
		/*Robustness feature got changed So Clear Temporary counts */
		s_correctionCount_i8=0;
		s_interStepCount_i8=0;
		V_StatusFlags_U8R &=~(M_Qualified_U8X|M_UnQualified_U8X);
		s_ModeTimer_i8 = 0;
		V_StatusFlags_U8R |=M_ModeDetection_U8X;
		V_StatusFlags_U8R &=~M_ModeCounting_U8X;
	}
	/* EasyCASE ) */
	/* EasyCASE ( 118 Counts And Composite Calculation */
	/* Increment the cycle and step to step counters */
	s_sampleCountForCycle_i16++;
	/* Increment the step to step count */
	gs_countStepToStep_i16++;
	
	/* Calculate the composite acceleration component value */
	composite_i16 = (short)(getAbsoluteShort(*f_x_i16) + getAbsoluteShort(*f_y_i16) + getAbsoluteShort(*f_z_i16));
		
	/* EasyCASE - */
	/*Increment Count Mode Elapse Timer*/
	s_ModeTimer_i8++;

	/* gs_compositeFilter[0]�� ���ο� ��(3���� ��)�� �����ϰ� �� �迭���� �����ܰ�� �̵�  */
	for (gs_FilterIndex=C_FilterTaps_U8X-C_CountOne_U8X;gs_FilterIndex>C_CountZero_U8X;gs_FilterIndex--)
	{
		gs_CompositeFilter[gs_FilterIndex] = gs_CompositeFilter[gs_FilterIndex-C_CountOne_U8X];
	}
	gs_CompositeFilter[C_CountZero_U8X] = composite_i16;
	/*Wait till atleast 24 values are received.*/
	/*The variable get cleared*/

	FilterResult_l32=C_Clear_U8X;
	for (gs_FilterIndex=C_CountZero_U8X;gs_FilterIndex<C_FilterTaps_U8X;gs_FilterIndex++)
	{
		FilterResult_l32 = FilterResult_l32 + (long)((long)gs_CompositeFilter[(C_FilterTaps_U8X-C_CountOne_U8X)-gs_FilterIndex]*(long)gc_CompositeFilterCoeff[gs_FilterIndex]);
	}
	/* Divide by 32768 to compensate Q15 format multiplication.*/
	composite_i16 = (uint16)(FilterResult_l32>>C_Q15ConversionFactor_U8X);
	//���� Ȱ���� �ӽ� ����
	temp_activity_total += (uint8)(composite_i16>>8);
	/****************************Filtering end************************************************************/

	/* Analyse the cycle trend for steps */
	trendFinder(composite_i16, &composite_i16);
	/* Check whether the trend is positive or negative */
	/* EasyCASE ) */
	/* EasyCASE ( 16 Human Activity */
	/* Check whether the trend is positive or negative */

	
	if (V_StatusFlags_U8R & M_NegativeTrend_U8X)
	{
		/* Acceleration for step start */
		s_resultHigh_i16 = composite_i16;
	}
	else
	{
		if (V_StatusFlags_U8R & M_PositiveTrend_U8X)
		{
			V_StatusFlags_U8R &=~(M_Qualified_U8X|M_UnQualified_U8X);
			composite_i16 = s_resultHigh_i16 - composite_i16;
			/* Clear the Activity status*/
			V_Activity_U8 = C_Clear_U8X;
			/* Check whether the step is walk step */
			/* EasyCASE ( 14 Lazy Walk */
			/* Check whether the step is lazy walk step */
			
			if (IS_BARK(composite_i16))
			{
				if (gs_countStepToStep_i16 > C_BarkLowerLimit_U8X)
				{
					V_StatusFlags_U8R |= M_Qualified_U8X;
					bark_count++;
				}
				else
				{
					V_StatusFlags_U8R |= M_UnQualified_U8X;
				}
				// Bark activity //
				V_Activity_U8 |= M_Bark_U8X;
			}
			
			if (IS_LAZY_WALK_STEP(composite_i16))
			{
				if (((gs_countStepToStep_i16 > C_LazyWalkStepToStepLowerLimit_U8X) && (gs_countStepToStep_i16 < C_LazyWalkStepToStepUpperLimit_U8X)))
				{
					V_StatusFlags_U8R |= M_Qualified_U8X;
					Acti_Lazy++;
				}
				else
				{
					V_StatusFlags_U8R |= M_UnQualified_U8X;
				}
				// Slow activity //
				V_Activity_U8 |= M_SlowWalk_U8X;
			}
			
			/* EasyCASE ) */
			/* EasyCASE ( 12 SMALL Walk */
			if(IS_SMALL_WALK_STEP(composite_i16))
			{
				if (((getAbsoluteShort(gs_countStepToStep_i16 -  s_countStepToStepPrev1_i16) <= MAX_COUNT_DIFFERENCE) ||( getAbsoluteShort(gs_countStepToStep_i16 -  s_countStepToStepPrev2_i16) <=MAX_COUNT_DIFFERENCE) )&&((gs_countStepToStep_i16 > C_SmallWalkStepToStepLowerLimit_U8X) && (gs_countStepToStep_i16 < C_SmallWalkStepToStepUpperLimit_U8X)))
				{
					V_StatusFlags_U8R |= M_Qualified_U8X;
					Acti_Walk++;
				}
				else
				{
					V_StatusFlags_U8R |= M_UnQualified_U8X;
					temp_activity_total = C_Clear_U8X;
				}
				// Medium activity
				V_Activity_U8 |= M_Walk_U8X;
			}

			/* EasyCASE ) */
			/* EasyCASE ( 11 Walk */
			if (IS_WALK_STEP(composite_i16))
			{
				
				if (((getAbsoluteShort(gs_countStepToStep_i16 -  s_countStepToStepPrev1_i16) <= MAX_COUNT_DIFFERENCE) ||( getAbsoluteShort(gs_countStepToStep_i16 -  s_countStepToStepPrev2_i16) <=MAX_COUNT_DIFFERENCE) )&&((gs_countStepToStep_i16 > C_WalkStepToStepLowerLimit_U8X) && (gs_countStepToStep_i16 < C_WalkStepToStepUpperLimit_U8X)))
				{
					V_StatusFlags_U8R |= M_Qualified_U8X;
					Acti_Walk++;
				}
				else
				{
					V_StatusFlags_U8R |= M_UnQualified_U8X;
					temp_activity_total = C_Clear_U8X;
				}
				// Medium activity
				V_Activity_U8 |= M_Walk_U8X;
			}
			
			/* EasyCASE ) */
			/* EasyCASE ( 12 Jog */
			/* Check whether the step is Jog step */
			if (IS_JOG_STEP(composite_i16))
			{
				if (((getAbsoluteShort(gs_countStepToStep_i16 -  s_countStepToStepPrev1_i16) <= MAX_COUNT_DIFFERENCE) || ( getAbsoluteShort(gs_countStepToStep_i16 -  s_countStepToStepPrev2_i16) <=MAX_COUNT_DIFFERENCE) )&&((gs_countStepToStep_i16 > C_JogStepToStepLowerLimit_U8X) && (gs_countStepToStep_i16 < C_JogStepToStepUpperLimit_U8X)))
				{
					V_StatusFlags_U8R |= M_Qualified_U8X;
					Acti_Play++;
				}
				else
				{
					V_StatusFlags_U8R |= M_UnQualified_U8X;
					temp_activity_total = C_Clear_U8X;
				}
				// Brisk activity //
				V_Activity_U8 |= M_Jog_U8X;
			}
			
			/* EasyCASE ) */
			/* EasyCASE ( 15 Step counting */
			/* EasyCASE ( 217 Time out in Detection */
			if ((s_ModeTimer_i8>C_DetectionModeTimeOut_U8X)&&( V_StatusFlags_U8R&M_ModeDetection_U8X)
			/* No steps for 2.8 seconds in Detection Mode */)
			{
				s_ModeTimer_i8=C_Clear_U8X;
				if (((V_StatusFlags_U8R & M_DisableRobustness_U8X)==0))
				{
					/* No activity in detection mode; so clear the Temporary step count*/
					s_correctionCount_i8=C_Clear_U8X;
					s_interStepCount_i8=C_Clear_U8X;
					V_StatusFlags_U8R &=~(M_Qualified_U8X|M_UnQualified_U8X);
					v_ErrorCount_u8=C_Clear_U8X;
				}
			}
			/* EasyCASE ) */
			/* EasyCASE ( 218 Time out in Counting */
			if ((s_ModeTimer_i8>C_CountingModeTimeOut_U8X)&&( V_StatusFlags_U8R&M_ModeCounting_U8X)
			/* No steps for 4 seconds in Count Mode*/)
			{
				s_ModeTimer_i8=C_Clear_U8X;
				if (((V_StatusFlags_U8R & M_DisableRobustness_U8X)==0))
				{
					/* No activity in counting mode; so clear the Temporary step count*/
					s_correctionCount_i8=C_Clear_U8X;
					V_StatusFlags_U8R &=~(M_Qualified_U8X|M_UnQualified_U8X);
					v_ErrorCount_u8=C_Clear_U8X;
					V_StatusFlags_U8R|=M_ModeDetection_U8X;
					V_StatusFlags_U8R&=~M_ModeCounting_U8X;
				}
			}
			/* EasyCASE ) */
			/*Check whether step is valid or not*/
			
			if (((V_StatusFlags_U8R & (M_Qualified_U8X|M_UnQualified_U8X))!=0))
			{
				/*If there is change in activity and the current result diff are
				greater than certain "Threshold" then  temporary counts are cleared .
				Threshold=(Largest of Current Result Diff and previous Result Diff)/2 .
				This is applicable in detection mode*/
					
				/* EasyCASE ( 220 Activity Monitor */
				if (((v_PreviousActivity_u8 & V_Activity_U8)==C_Clear_U8X) && (v_PreviousActivity_u8 !=C_Clear_U8X) &&( V_StatusFlags_U8R&M_ModeDetection_U8X)&&(((getAbsoluteShort(composite_i16-v_PreResultDiff_s16r))<<C_CountOne_U8X)>((composite_i16>v_PreResultDiff_s16r)?composite_i16:v_PreResultDiff_s16r))&&((V_StatusFlags_U8R & M_DisableRobustness_U8X)==0))
				{
					/* Activities differ in Detection state;  So clear the temporary step count*/
					s_interStepCount_i8 = C_Clear_U8X;
					s_correctionCount_i8=C_Clear_U8X;
					V_StatusFlags_U8R &=~(M_Qualified_U8X|M_UnQualified_U8X);
				}
				/* EasyCASE ) */
				/*Stores the current Activity Type*/
				v_PreviousActivity_u8=V_Activity_U8;
				/*Stores the current result Diff*/
				v_PreResultDiff_s16r=composite_i16;
				/*Error count cleared*/
				v_ErrorCount_u8=C_Clear_U8X;
				/*Reset the Mode Timer*/
				s_ModeTimer_i8=C_Clear_U8X;
				/* EasyCASE - */
				/* Check whether the  step is Qualified */
				
				if (V_StatusFlags_U8R & M_Qualified_U8X)
				{
					/* Check whether the mode is counting mode */
					if (V_StatusFlags_U8R&M_ModeCounting_U8X)	
					{
						/* EasyCASE ( 222 Counting Mode */
						/*Check whether correction count >3 in Counting Mode*/
						if (s_correctionCount_i8>C_CorrectionCountLimit_U8X)
						{
							/* Add the step count with Correction count */
							gs_stepCount_i16+=(s_correctionCount_i8+C_CountOne_U8X);
							/* Reset the correction counter */
							s_correctionCount_i8 = C_Clear_U8X;
						}
						else
						{
							/* Increment the step count */
							gs_stepCount_i16++;
							activity_total += (uint16)(temp_activity_total>>12) & 0xFFFF;
						}
						/* EasyCASE ) */
                        // ���� �ִ�ġ 5����..
                        if(gs_stepCount_i16 > 50000)
                        {
                            gs_stepCount_i16 = 50000;
                        }

					}
					else
					{
						/*Check whether current mode is Detection Mode*/
						/* EasyCASE ( 223 Detection Mode */
						if (V_StatusFlags_U8R&M_ModeDetection_U8X)
						{
							/*Correction count is added to interstep count whwn correction count >3 in detection mode*/
							if (s_correctionCount_i8>C_CorrectionCountLimit_U8X)
							{
								/* Increment the step count */
								s_interStepCount_i8+=(s_correctionCount_i8+1);
								/* Reset the correction counter */
								s_correctionCount_i8 = C_Clear_U8X;
							}
							else
							{
								/* Increment the step count */
								s_interStepCount_i8++;
							}
							/*When interstep count > 9 mode changed to counting in case if Robustness feature enabled When interstep count > 3 mode changed to counting in case if Robustness feature disabled*/
							
							
							//if ((s_interStepCount_i8 > C_InterStepCountLimit_U8X)&&((V_StatusFlags_U8R & M_DisableRobustness_U8X)==0))
							if (((s_interStepCount_i8 > C_InterStepCountLimit_U8X)))
							{
								// Set the mode to MODE_COUNTING 
								V_StatusFlags_U8R|=M_ModeCounting_U8X;
								V_StatusFlags_U8R&=~M_ModeDetection_U8X;
								// Increment the step 
								
								gs_stepCount_i16+=(s_interStepCount_i8+s_correctionCount_i8);

								//Reset the interstep counter
								s_interStepCount_i8 = C_Clear_U8X;
								//Reset the correction counter 
								s_correctionCount_i8 = C_Clear_U8X;
							}
						}
					/* EasyCASE ) */
					}
				} /*Check whether step is valid or not..........end*/
				else
				{
					/* EasyCASE ( 221 Correction Count */
					/*Check whether Step is unqualified*/
					if (V_StatusFlags_U8R & M_UnQualified_U8X)
					{
						/* Increment the correction count */
						s_correctionCount_i8++;
					}
				/* EasyCASE ) */
				}
			}
			else
			{
				/* EasyCASE ( 219 Error Count */
				/*Error count is incremented if the step is notvalid and not due to noise*/
				if ((composite_i16>C_SensorNoiseLevel_U8X))
				{
					/*Error count is incremented*/
					v_ErrorCount_u8++;
				}
				/*When the error count becomes greater than 3 the temporary counts are cleared*/
				if (v_ErrorCount_u8>C_ErrorCountLimit_U8X)
				{
					/*The mode changed to detection and counts are cleared*/
					V_StatusFlags_U8R|=M_ModeDetection_U8X;
					V_StatusFlags_U8R&=~M_ModeCounting_U8X;
					v_ErrorCount_u8=C_Clear_U8X;
					s_correctionCount_i8=C_Clear_U8X;
					s_interStepCount_i8=C_Clear_U8X;
					V_StatusFlags_U8R &=~(M_Qualified_U8X|M_UnQualified_U8X);
					s_ModeTimer_i8 = C_Clear_U8X;
				}
				/* EasyCASE ) */
			}	
			/* EasyCASE ( 224 Step to Step Count Updation */
			/*Count step to step is updated if the trend change is not due to noise*/
			if (composite_i16>C_SensorNoiseLevel_U8X)
			{
				/* Update the last, secondlast and thridlast count variables */
				s_countStepToStepPrev2_i16 = s_countStepToStepPrev1_i16;
				s_countStepToStepPrev1_i16 = gs_countStepToStep_i16;
				gs_countStepToStep_i16 = C_Clear_U8X;
			}
			/* EasyCASE ) */
			/* EasyCASE ) */
			/* Reset the sample count for cycle */
			s_sampleCountForCycle_i16 = C_Clear_U8X;
		}
	}
	distance = gs_stepCount_i16 + length;
	step_count = Acti_Lazy + Acti_Walk + Acti_Play;

	/* EasyCASE ) */
	/*Current status are stored*/
	v_PreStatusFlags_u8r=V_StatusFlags_U8R;
	/* return the composite value */
	//return composite_i16;
	//return gs_stepCount_i16;
	//return distance;
	//return step_count;
	return bark_count;
}

/*******************************************************************************
  Function Name  : void InitAlgo(void)
    Input          : None
     Output         : None
     Scope          : Global
   
     Detailed Description:
      This function will initialze the variables that are used in the Algorithm.
 ******************************************************************************/
void InitAlgo(uint8 v_GRange_u8r)
{
       /* Reset the activity as 0 */
       V_Activity_U8 = C_Clear_U8X;       
       /* Reset the step count */
       gs_stepCount_i16 = C_Clear_U8X;
       /* Set the Flag so that algo starts fresh */
       V_StatusFlags_U8R = C_Clear_U8X;
       V_StatusFlags_U8R |= (M_ModeDetection_U8X|M_AlgoReset_U8X);
       V_DivideFactor_U8R=v_GRange_u8r;
       /*Default lower limit set as robust*/
       V_LazyWalkLowerLimit_U8R=LAZY_WALKING_LOWER_LIMIT_Robust;
       /* Activite status*/
       Acti_Lazy = C_Clear_U8X;
       Acti_Walk = C_Clear_U8X;
       Acti_Play = C_Clear_U8X;
}


/*******************************************************************************
 Function Name : unsigned char getActivity(void)
  - Input         : None
  - Output        : None

 Detailed Description:
 This function will Return the Activity of the Pedometer.
*******************************************************************************/
unsigned char getActivity(void)
{
	char v_Activity_u8r;
	if (V_Activity_U8&M_Walk_U8X)
	{
		/*Current activity is walk*/
		v_Activity_u8r=0x11;
	}
	else
	{
		if (V_Activity_U8&M_SlowWalk_U8X)
		{
			/*Current activity is slow walk*/
			v_Activity_u8r=0x10;
		}
		else
		{
			if (V_Activity_U8&M_Jog_U8X)
			{
				/*Current activity is jog*/
				v_Activity_u8r=0x12;
			}
			else
			{
				v_Activity_u8r=C_Clear_U8X;
			}
		}
	}
	return (v_Activity_u8r);
}




static short getAbsoluteShort(int8 f_val_i16)
{
	return (f_val_i16 < 0)? -f_val_i16 : f_val_i16;
}



/*******************************************************************************
     Function Name   : static char trendFinder()
     Input           : short f_composite_i16
                       short* f_optimalComposite_i16p
     Output          : Returns 1 if the trend is positive
                       Returns -1 if the trend is negative
                       Returns 0 if there is no trend change
     Scope           : Local
*******************************************************************************/  
static void trendFinder(uint16 f_composite_i16, uint16* f_optimalComposite_i16p)
{
	/* Holds the last composite value */
	static int16     s_compositePrev1_i16 = -1;
	/* Holds the second last composite value */
	static int16     s_compositePrev2_i16 = -1;
	/* Holds the current trend */
	static int8      s_currTrend_i8 = -1;
	
	/* Holds the Change in the trend bit �ʱ�ȭ */
	V_StatusFlags_U8R &=~(M_NegativeTrend_U8X|M_PositiveTrend_U8X);
		
	/* Check whether the current trend is positive */
	if (s_currTrend_i8 == 1)
	{
		/* check whether there is a trend change between *
		* the present and the previous composite values */
		if (f_composite_i16 < s_compositePrev1_i16 )
		//if (f_composite_i16 < s_compositePrev1_i16 && f_composite_i16 < s_compositePrev2_i16)
		{
			/* Set the current trend as negative */
			s_currTrend_i8 = -1;
			/* Set the change in trend as negative */
			V_StatusFlags_U8R |= M_NegativeTrend_U8X;
			/* Return the optimal composite value */
			*f_optimalComposite_i16p = (s_compositePrev1_i16 > s_compositePrev2_i16)?s_compositePrev1_i16 : s_compositePrev2_i16;
		}
		/* If the current trend is negative */
	}
	else
	{
			/* check whether there is a trend change between *
		* the present and the previous composite values */
		if (f_composite_i16 > s_compositePrev1_i16)
		//if (f_composite_i16 > s_compositePrev1_i16 && f_composite_i16 > s_compositePrev2_i16)
		{
			/* Set the current trend as Positive */
			s_currTrend_i8 = 1;
			/* Set the change in trend as Positive */
			V_StatusFlags_U8R |= M_PositiveTrend_U8X;
			/* Return the optimal composite value */
			*f_optimalComposite_i16p = (s_compositePrev1_i16 < s_compositePrev2_i16)?s_compositePrev1_i16 : s_compositePrev2_i16;
		}
	}
	/* Update the second last composite value */
	s_compositePrev2_i16 = s_compositePrev1_i16;
	/* Update the last composite values */
	s_compositePrev1_i16 = f_composite_i16;
	/* Return the Change in trend */
}

/*******************************************************************************
 Function Name   : accelRead
 * @brief   Called by the application to read accelerometer data
 *          and put data in accelerometer profile
 * @param   none
 * @return  none
 ******************************************************************************/
void pedometerProcess( void )
{ 
  
  BMA250ReadChip();
  // ���� �� ���� ó��
  processAccelarationData(&sysSensor.accx, &sysSensor.accy, &sysSensor.accz);
  
  /*Step �� */
  sysSensor.pedometer = gs_stepCount_i16;
  
}